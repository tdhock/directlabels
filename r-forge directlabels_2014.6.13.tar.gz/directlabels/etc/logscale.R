## log scales do not work with direct labels? why?
